(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/admin/SignOutButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SignOutButton",
    ()=>SignOutButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/log-out.js [app-client] (ecmascript) <export default as LogOut>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react/index.js [app-client] (ecmascript)");
"use client";
;
;
;
;
function SignOutButton() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "6f47cc9d1497d26000a74a535e77296bfb88e60280d763f2d63945e78b0bc887") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6f47cc9d1497d26000a74a535e77296bfb88e60280d763f2d63945e78b0bc887";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: _SignOutButtonButtonOnClick,
            className: "inline-flex items-center gap-2 rounded-full border border-zinc-300 px-4 py-1 text-xs font-medium text-zinc-100 hover:bg-white/5 hover:border-zinc-100 transition-colors",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__["LogOut"], {
                    className: "h-4 w-4 text-zinc-100"
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/SignOutButton.tsx",
                    lineNumber: 16,
                    columnNumber: 250
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: "Déconnexion"
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/SignOutButton.tsx",
                    lineNumber: 16,
                    columnNumber: 294
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/SignOutButton.tsx",
            lineNumber: 16,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c = SignOutButton;
function _SignOutButtonButtonOnClick() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signOut"])({
        callbackUrl: "/login"
    });
}
var _c;
__turbopack_context__.k.register(_c, "SignOutButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/admin/ProductImagesUploader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductImagesUploader",
    ()=>ProductImagesUploader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ProductImagesUploader(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18);
    if ($[0] !== "d87ec984c14e7687967b4eb5db1da79a84b51c74cd25d74801e6ed4b56f08ec9") {
        for(let $i = 0; $i < 18; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d87ec984c14e7687967b4eb5db1da79a84b51c74cd25d74801e6ed4b56f08ec9";
    }
    const { fieldName: t1, children } = t0;
    const fieldName = t1 === undefined ? "files" : t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [];
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    const [previews, setPreviews] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = [];
        $[2] = t3;
    } else {
        t3 = $[2];
    }
    const [files, setFiles] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t3);
    const [primaryIndex, setPrimaryIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t4;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "ProductImagesUploader[handleChange]": (e)=>{
                const files_0 = e.target.files;
                if (!files_0 || files_0.length === 0) {
                    setPreviews([]);
                    setFiles([]);
                    setPrimaryIndex(-1);
                    return;
                }
                const selectedFiles = Array.from(files_0);
                const urls = selectedFiles.map(_ProductImagesUploaderHandleChangeSelectedFilesMap);
                setFiles(selectedFiles);
                setPreviews(urls);
                setPrimaryIndex(-1);
            }
        })["ProductImagesUploader[handleChange]"];
        $[3] = t4;
    } else {
        t4 = $[3];
    }
    const handleChange = t4;
    let t5;
    if ($[4] !== children || $[5] !== fieldName || $[6] !== files || $[7] !== previews || $[8] !== primaryIndex) {
        const handleRemove = {
            "ProductImagesUploader[handleRemove]": (index, e_0)=>{
                e_0.stopPropagation();
                const newFiles = files.filter({
                    "ProductImagesUploader[handleRemove > files.filter()]": (_, i)=>i !== index
                }["ProductImagesUploader[handleRemove > files.filter()]"]);
                const newPreviews = previews.filter({
                    "ProductImagesUploader[handleRemove > previews.filter()]": (__0, i_0)=>i_0 !== index
                }["ProductImagesUploader[handleRemove > previews.filter()]"]);
                setFiles(newFiles);
                setPreviews(newPreviews);
                if (inputRef.current) {
                    const dataTransfer = new DataTransfer();
                    newFiles.forEach({
                        "ProductImagesUploader[handleRemove > newFiles.forEach()]": (file_0)=>dataTransfer.items.add(file_0)
                    }["ProductImagesUploader[handleRemove > newFiles.forEach()]"]);
                    inputRef.current.files = dataTransfer.files;
                }
                if (newPreviews.length === 0) {
                    setPrimaryIndex(-1);
                    return;
                }
                if (index === primaryIndex) {
                    const newIndex = newPreviews.length > 0 ? 0 : -1;
                    setPrimaryIndex(newIndex);
                } else {
                    if (index < primaryIndex) {
                        setPrimaryIndex(_ProductImagesUploaderHandleRemoveSetPrimaryIndex);
                    }
                }
            }
        }["ProductImagesUploader[handleRemove]"];
        let t6;
        if ($[10] !== fieldName) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                id: "product-files",
                name: fieldName,
                type: "file",
                multiple: true,
                accept: "image/*",
                className: "sr-only",
                ref: inputRef,
                onChange: handleChange
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                lineNumber: 99,
                columnNumber: 12
            }, this);
            $[10] = fieldName;
            $[11] = t6;
        } else {
            t6 = $[11];
        }
        let t7;
        if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: "product-files",
                className: "inline-flex cursor-pointer items-center rounded-full bg-zinc-900 px-4 py-2 text-xs font-semibold text-white shadow hover:bg-zinc-800",
                children: "Ajouter des images"
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                lineNumber: 107,
                columnNumber: 12
            }, this);
            $[12] = t7;
        } else {
            t7 = $[12];
        }
        let t8;
        if ($[13] !== primaryIndex) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "hidden",
                name: "primaryIndex",
                value: primaryIndex
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                lineNumber: 114,
                columnNumber: 12
            }, this);
            $[13] = primaryIndex;
            $[14] = t8;
        } else {
            t8 = $[14];
        }
        let t9;
        if ($[15] !== t6 || $[16] !== t8) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3",
                children: [
                    t6,
                    t7,
                    t8
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                lineNumber: 122,
                columnNumber: 12
            }, this);
            $[15] = t6;
            $[16] = t8;
            $[17] = t9;
        } else {
            t9 = $[17];
        }
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-2",
            children: [
                t9,
                (previews.length > 0 || children) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-[11px] text-zinc-500",
                            children: "Cliquez sur une image pour la définir comme principale."
                        }, void 0, false, {
                            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                            lineNumber: 129,
                            columnNumber: 106
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap gap-3",
                            children: [
                                previews.map({
                                    "ProductImagesUploader[previews.map()]": (src, index_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            onClick: {
                                                "ProductImagesUploader[previews.map() > <div>.onClick]": ()=>setPrimaryIndex(index_0)
                                            }["ProductImagesUploader[previews.map() > <div>.onClick]"],
                                            className: `relative h-16 w-16 overflow-hidden rounded-xl border cursor-pointer ${primaryIndex === index_0 ? "border-[#ff1744] ring-2 ring-[#ff1744]" : "border-zinc-200"}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: src,
                                                    alt: `Preview ${index_0 + 1}`,
                                                    className: "h-full w-full object-cover"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                                    lineNumber: 132,
                                                    columnNumber: 246
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: {
                                                        "ProductImagesUploader[previews.map() > <button>.onClick]": (e_1)=>handleRemove(index_0, e_1)
                                                    }["ProductImagesUploader[previews.map() > <button>.onClick]"],
                                                    className: "absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-600/80 text-[9px] text-white hover:bg-red-700",
                                                    children: "×"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                                    lineNumber: 132,
                                                    columnNumber: 333
                                                }, this),
                                                primaryIndex === index_0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "absolute inset-x-0 bottom-0 bg-black/60 text-[9px] font-semibold text-white px-1 py-0.5 text-center",
                                                    children: "Principale"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                                    lineNumber: 134,
                                                    columnNumber: 259
                                                }, this)
                                            ]
                                        }, index_0, true, {
                                            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                            lineNumber: 130,
                                            columnNumber: 72
                                        }, this)
                                }["ProductImagesUploader[previews.map()]"]),
                                children
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                            lineNumber: 129,
                            columnNumber: 206
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                    lineNumber: 129,
                    columnNumber: 79
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
            lineNumber: 129,
            columnNumber: 10
        }, this);
        $[4] = children;
        $[5] = fieldName;
        $[6] = files;
        $[7] = previews;
        $[8] = primaryIndex;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    return t5;
}
_s(ProductImagesUploader, "L/KEYL1XX4qrG+QQdqZaKfhfWek=");
_c = ProductImagesUploader;
function _ProductImagesUploaderHandleRemoveSetPrimaryIndex(prev) {
    return prev - 1;
}
function _ProductImagesUploaderHandleChangeSelectedFilesMap(file) {
    return URL.createObjectURL(file);
}
var _c;
__turbopack_context__.k.register(_c, "ProductImagesUploader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/admin/ProductFeaturesNewEditor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductFeaturesNewEditor",
    ()=>ProductFeaturesNewEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ProductFeaturesNewEditor() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23);
    if ($[0] !== "5c547bbafb23a3a6741347f4a4eaaab4755f76e02888470ea3a08b1a51bc8e02") {
        for(let $i = 0; $i < 23; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5c547bbafb23a3a6741347f4a4eaaab4755f76e02888470ea3a08b1a51bc8e02";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [
            {
                title: "",
                description: "",
                imageFile: null,
                previewUrl: ""
            }
        ];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [rows, setRows] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    let t2;
    if ($[2] !== rows) {
        t1 = ({
            "ProductFeaturesNewEditor[useEffect()]": ()=>()=>{
                    rows.forEach(_ProductFeaturesNewEditorUseEffectAnonymousRowsForEach);
                }
        })["ProductFeaturesNewEditor[useEffect()]"];
        t2 = [
            rows
        ];
        $[2] = rows;
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    const validateImageFile = _ProductFeaturesNewEditorValidateImageFile;
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "ProductFeaturesNewEditor[handleTitleChange]": (index, value)=>{
                setRows({
                    "ProductFeaturesNewEditor[handleTitleChange > setRows()]": (prev)=>prev.map({
                            "ProductFeaturesNewEditor[handleTitleChange > setRows() > prev.map()]": (row_0, i)=>i === index ? {
                                    ...row_0,
                                    title: value
                                } : row_0
                        }["ProductFeaturesNewEditor[handleTitleChange > setRows() > prev.map()]"])
                }["ProductFeaturesNewEditor[handleTitleChange > setRows()]"]);
            }
        })["ProductFeaturesNewEditor[handleTitleChange]"];
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const handleTitleChange = t3;
    let t4;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "ProductFeaturesNewEditor[handleDescriptionChange]": (index_0, value_0)=>{
                setRows({
                    "ProductFeaturesNewEditor[handleDescriptionChange > setRows()]": (prev_0)=>prev_0.map({
                            "ProductFeaturesNewEditor[handleDescriptionChange > setRows() > prev_0.map()]": (row_1, i_0)=>i_0 === index_0 ? {
                                    ...row_1,
                                    description: value_0
                                } : row_1
                        }["ProductFeaturesNewEditor[handleDescriptionChange > setRows() > prev_0.map()]"])
                }["ProductFeaturesNewEditor[handleDescriptionChange > setRows()]"]);
            }
        })["ProductFeaturesNewEditor[handleDescriptionChange]"];
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    const handleDescriptionChange = t4;
    let t5;
    if ($[7] !== rows) {
        t5 = ({
            "ProductFeaturesNewEditor[handleImageChange]": (e, index_1)=>{
                const file_0 = e.target.files?.[0];
                if (!file_0) {
                    return;
                }
                if (!validateImageFile(file_0)) {
                    e.target.value = "";
                    return;
                }
                const previewUrl = URL.createObjectURL(file_0);
                const prevRow = rows[index_1];
                if (prevRow?.previewUrl && prevRow.previewUrl.startsWith("blob:")) {
                    URL.revokeObjectURL(prevRow.previewUrl);
                }
                setRows({
                    "ProductFeaturesNewEditor[handleImageChange > setRows()]": (prev_1)=>prev_1.map({
                            "ProductFeaturesNewEditor[handleImageChange > setRows() > prev_1.map()]": (row_2, i_1)=>i_1 === index_1 ? {
                                    ...row_2,
                                    imageFile: file_0,
                                    previewUrl
                                } : row_2
                        }["ProductFeaturesNewEditor[handleImageChange > setRows() > prev_1.map()]"])
                }["ProductFeaturesNewEditor[handleImageChange > setRows()]"]);
            }
        })["ProductFeaturesNewEditor[handleImageChange]"];
        $[7] = rows;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    const handleImageChange = t5;
    let t6;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "ProductFeaturesNewEditor[handleAdd]": ()=>{
                setRows(_ProductFeaturesNewEditorHandleAddSetRows);
            }
        })["ProductFeaturesNewEditor[handleAdd]"];
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    const handleAdd = t6;
    let t7;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = ({
            "ProductFeaturesNewEditor[handleRemove]": (index_2)=>{
                setRows({
                    "ProductFeaturesNewEditor[handleRemove > setRows()]": (prev_3)=>prev_3.filter({
                            "ProductFeaturesNewEditor[handleRemove > setRows() > prev_3.filter()]": (_, i_2)=>i_2 !== index_2
                        }["ProductFeaturesNewEditor[handleRemove > setRows() > prev_3.filter()]"])
                }["ProductFeaturesNewEditor[handleRemove > setRows()]"]);
            }
        })["ProductFeaturesNewEditor[handleRemove]"];
        $[10] = t7;
    } else {
        t7 = $[10];
    }
    const handleRemove = t7;
    let t8;
    if ($[11] !== handleImageChange || $[12] !== rows) {
        let t9;
        if ($[14] !== handleImageChange) {
            t9 = ({
                "ProductFeaturesNewEditor[rows.map()]": (row_3, index_3)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-3 rounded-xl border border-zinc-200 bg-zinc-50/60 p-3 md:flex-row md:items-start md:gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full md:w-1/3 space-y-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "text-[11px] font-medium text-zinc-700",
                                        children: [
                                            "Image de la caractéristique ",
                                            !row_3.previewUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-red-500",
                                                children: "*"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                                lineNumber: 155,
                                                columnNumber: 358
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                        lineNumber: 155,
                                        columnNumber: 251
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        id: `featureNewImage_${index_3}`,
                                        type: "file",
                                        name: `featureNewImage_${index_3}`,
                                        accept: "image/*",
                                        className: "hidden",
                                        onChange: {
                                            "ProductFeaturesNewEditor[rows.map() > <input>.onChange]": (e_0)=>handleImageChange(e_0, index_3)
                                        }["ProductFeaturesNewEditor[rows.map() > <input>.onChange]"]
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                        lineNumber: 155,
                                        columnNumber: 406
                                    }, this),
                                    row_3.previewUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative h-32 w-32 rounded-3xl border border-zinc-200 bg-white shadow-sm flex items-center justify-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: `featureNewImage_${index_3}`,
                                                className: "h-24 w-24 overflow-hidden rounded-2xl bg-zinc-50 cursor-pointer",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: row_3.previewUrl,
                                                    alt: `Prévisualisation ${index_3 + 1}`,
                                                    className: "h-full w-full object-cover",
                                                    onError: _ProductFeaturesNewEditorRowsMapImgOnError
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                                    lineNumber: 157,
                                                    columnNumber: 342
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                                lineNumber: 157,
                                                columnNumber: 220
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: {
                                                    "ProductFeaturesNewEditor[rows.map() > <button>.onClick]": ()=>{
                                                        if (row_3.previewUrl && row_3.previewUrl.startsWith("blob:")) {
                                                            URL.revokeObjectURL(row_3.previewUrl);
                                                        }
                                                        setRows({
                                                            "ProductFeaturesNewEditor[rows.map() > <button>.onClick > setRows()]": (prev_4)=>prev_4.map({
                                                                    "ProductFeaturesNewEditor[rows.map() > <button>.onClick > setRows() > prev_4.map()]": (r, i_3)=>i_3 === index_3 ? {
                                                                            ...r,
                                                                            previewUrl: "",
                                                                            imageFile: null
                                                                        } : r
                                                                }["ProductFeaturesNewEditor[rows.map() > <button>.onClick > setRows() > prev_4.map()]"])
                                                        }["ProductFeaturesNewEditor[rows.map() > <button>.onClick > setRows()]"]);
                                                    }
                                                }["ProductFeaturesNewEditor[rows.map() > <button>.onClick]"],
                                                className: "absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-[11px] font-semibold text-white shadow-md hover:bg-red-600",
                                                "aria-label": "Retirer l'image",
                                                children: "×"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                                lineNumber: 157,
                                                columnNumber: 512
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                        lineNumber: 157,
                                        columnNumber: 97
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: `featureNewImage_${index_3}`,
                                        className: "flex cursor-pointer items-center gap-2 rounded-xl border border-dashed border-red-200 bg-red-50/60 px-3 py-2 text-[10px] text-red-700 hover:bg-red-100 hover:border-red-300",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-[12px] font-bold text-white",
                                                children: "+"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                                lineNumber: 172,
                                                columnNumber: 521
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex flex-col",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-semibold",
                                                        children: "Ajouter une image"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                                        lineNumber: 172,
                                                        columnNumber: 677
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[9px] text-red-500/80",
                                                        children: "JPG, PNG, WebP, GIF (max 5MB)"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                                        lineNumber: 172,
                                                        columnNumber: 733
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                                lineNumber: 172,
                                                columnNumber: 645
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                        lineNumber: 172,
                                        columnNumber: 291
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "hidden",
                                        name: "featureImageUrls",
                                        value: row_3.previewUrl || ""
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                        lineNumber: 172,
                                        columnNumber: 830
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                lineNumber: 155,
                                columnNumber: 208
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "text-[11px] font-medium text-zinc-700",
                                                children: [
                                                    "Titre de la caractéristique ",
                                                    index_3 + 1
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                                lineNumber: 172,
                                                columnNumber: 975
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                name: "featureTitles",
                                                value: row_3.title,
                                                onChange: {
                                                    "ProductFeaturesNewEditor[rows.map() > <input>.onChange]": (e_2)=>handleTitleChange(index_3, e_2.target.value)
                                                }["ProductFeaturesNewEditor[rows.map() > <input>.onChange]"],
                                                className: "w-full rounded-md border border-zinc-300 px-3 py-2 text-xs outline-none focus:border-zinc-900",
                                                placeholder: `Caractéristique ${index_3 + 1}`
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                                lineNumber: 172,
                                                columnNumber: 1081
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                        lineNumber: 172,
                                        columnNumber: 948
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "text-[11px] font-medium text-zinc-700",
                                                children: [
                                                    "Paragraphe de la caractéristique ",
                                                    index_3 + 1
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                                lineNumber: 174,
                                                columnNumber: 265
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                name: "featureDescriptions",
                                                value: row_3.description,
                                                onChange: {
                                                    "ProductFeaturesNewEditor[rows.map() > <textarea>.onChange]": (e_3)=>handleDescriptionChange(index_3, e_3.target.value)
                                                }["ProductFeaturesNewEditor[rows.map() > <textarea>.onChange]"],
                                                className: "w-full rounded-md border border-zinc-300 px-3 py-2 text-xs outline-none focus:border-zinc-900",
                                                rows: 2
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                                lineNumber: 174,
                                                columnNumber: 376
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                        lineNumber: 174,
                                        columnNumber: 238
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                lineNumber: 172,
                                columnNumber: 914
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center pt-1 md:pt-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-xs text-red-500",
                                        children: !row_3.previewUrl && "Une image est requise"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                        lineNumber: 176,
                                        columnNumber: 273
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: {
                                            "ProductFeaturesNewEditor[rows.map() > <button>.onClick]": ()=>handleRemove(index_3)
                                        }["ProductFeaturesNewEditor[rows.map() > <button>.onClick]"],
                                        className: "text-[11px] text-red-600 hover:text-red-700",
                                        children: "Supprimer"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                        lineNumber: 176,
                                        columnNumber: 363
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                                lineNumber: 176,
                                columnNumber: 209
                            }, this)
                        ]
                    }, index_3, true, {
                        fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                        lineNumber: 155,
                        columnNumber: 69
                    }, this)
            })["ProductFeaturesNewEditor[rows.map()]"];
            $[14] = handleImageChange;
            $[15] = t9;
        } else {
            t9 = $[15];
        }
        t8 = rows.map(t9);
        $[11] = handleImageChange;
        $[12] = rows;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-[11px] text-zinc-500",
            children: "Vous pouvez ajouter plusieurs caractéristiques. Elles seront affichées dans l'ordre de la liste."
        }, void 0, false, {
            fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
            lineNumber: 194,
            columnNumber: 10
        }, this);
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    const t10 = rows.length >= 5;
    const t11 = rows.length > 0 && `(${rows.length}/5)`;
    let t12;
    if ($[17] !== t10 || $[18] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-between items-center pt-1",
            children: [
                t9,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    onClick: handleAdd,
                    className: "inline-flex items-center rounded-full bg-zinc-900 px-3 py-1.5 text-[11px] font-medium text-white hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed",
                    disabled: t10,
                    children: [
                        "+ Ajouter une caractéristique ",
                        t11
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
                    lineNumber: 203,
                    columnNumber: 71
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
            lineNumber: 203,
            columnNumber: 11
        }, this);
        $[17] = t10;
        $[18] = t11;
        $[19] = t12;
    } else {
        t12 = $[19];
    }
    let t13;
    if ($[20] !== t12 || $[21] !== t8) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-4",
            children: [
                t8,
                t12
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/ProductFeaturesNewEditor.tsx",
            lineNumber: 212,
            columnNumber: 11
        }, this);
        $[20] = t12;
        $[21] = t8;
        $[22] = t13;
    } else {
        t13 = $[22];
    }
    return t13;
}
_s(ProductFeaturesNewEditor, "rVsJp5jQ5+qkOSSKarS1QVR2AsY=");
_c = ProductFeaturesNewEditor;
function _ProductFeaturesNewEditorRowsMapImgOnError(e_1) {
    const target = e_1.target;
    target.style.display = "none";
}
function _ProductFeaturesNewEditorHandleAddSetRows(prev_2) {
    return [
        ...prev_2,
        {
            title: "",
            description: "",
            imageFile: null,
            previewUrl: ""
        }
    ];
}
function _ProductFeaturesNewEditorValidateImageFile(file) {
    const validTypes = [
        "image/jpeg",
        "image/png",
        "image/webp",
        "image/gif"
    ];
    if (!validTypes.includes(file.type)) {
        alert("Veuillez s\xE9lectionner une image au format JPG, PNG, WebP ou GIF.");
        return false;
    }
    if (file.size > 5242880) {
        alert("La taille de l'image ne doit pas d\xE9passer 5 Mo.");
        return false;
    }
    return true;
}
function _ProductFeaturesNewEditorUseEffectAnonymousRowsForEach(row) {
    if (row.previewUrl && row.previewUrl.startsWith("blob:")) {
        URL.revokeObjectURL(row.previewUrl);
    }
}
var _c;
__turbopack_context__.k.register(_c, "ProductFeaturesNewEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_admin_0d3de478._.js.map