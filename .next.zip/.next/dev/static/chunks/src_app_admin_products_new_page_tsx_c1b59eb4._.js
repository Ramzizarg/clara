(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_81351861._.js",
  "static/chunks/src_components_admin_0d3de478._.js"
],
    source: "dynamic"
});
