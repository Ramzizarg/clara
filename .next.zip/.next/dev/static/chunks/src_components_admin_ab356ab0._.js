(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/admin/SignOutButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SignOutButton",
    ()=>SignOutButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/log-out.js [app-client] (ecmascript) <export default as LogOut>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react/index.js [app-client] (ecmascript)");
"use client";
;
;
;
;
function SignOutButton() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "6f47cc9d1497d26000a74a535e77296bfb88e60280d763f2d63945e78b0bc887") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6f47cc9d1497d26000a74a535e77296bfb88e60280d763f2d63945e78b0bc887";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: _SignOutButtonButtonOnClick,
            className: "inline-flex items-center gap-2 rounded-full border border-zinc-300 px-4 py-1 text-xs font-medium text-zinc-100 hover:bg-white/5 hover:border-zinc-100 transition-colors",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__["LogOut"], {
                    className: "h-4 w-4 text-zinc-100"
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/SignOutButton.tsx",
                    lineNumber: 16,
                    columnNumber: 250
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: "Déconnexion"
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/SignOutButton.tsx",
                    lineNumber: 16,
                    columnNumber: 294
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/SignOutButton.tsx",
            lineNumber: 16,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c = SignOutButton;
function _SignOutButtonButtonOnClick() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signOut"])({
        callbackUrl: "/login"
    });
}
var _c;
__turbopack_context__.k.register(_c, "SignOutButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/admin/ProductImagesUploader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductImagesUploader",
    ()=>ProductImagesUploader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ProductImagesUploader(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18);
    if ($[0] !== "d87ec984c14e7687967b4eb5db1da79a84b51c74cd25d74801e6ed4b56f08ec9") {
        for(let $i = 0; $i < 18; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d87ec984c14e7687967b4eb5db1da79a84b51c74cd25d74801e6ed4b56f08ec9";
    }
    const { fieldName: t1, children } = t0;
    const fieldName = t1 === undefined ? "files" : t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [];
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    const [previews, setPreviews] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = [];
        $[2] = t3;
    } else {
        t3 = $[2];
    }
    const [files, setFiles] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t3);
    const [primaryIndex, setPrimaryIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t4;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "ProductImagesUploader[handleChange]": (e)=>{
                const files_0 = e.target.files;
                if (!files_0 || files_0.length === 0) {
                    setPreviews([]);
                    setFiles([]);
                    setPrimaryIndex(-1);
                    return;
                }
                const selectedFiles = Array.from(files_0);
                const urls = selectedFiles.map(_ProductImagesUploaderHandleChangeSelectedFilesMap);
                setFiles(selectedFiles);
                setPreviews(urls);
                setPrimaryIndex(-1);
            }
        })["ProductImagesUploader[handleChange]"];
        $[3] = t4;
    } else {
        t4 = $[3];
    }
    const handleChange = t4;
    let t5;
    if ($[4] !== children || $[5] !== fieldName || $[6] !== files || $[7] !== previews || $[8] !== primaryIndex) {
        const handleRemove = {
            "ProductImagesUploader[handleRemove]": (index, e_0)=>{
                e_0.stopPropagation();
                const newFiles = files.filter({
                    "ProductImagesUploader[handleRemove > files.filter()]": (_, i)=>i !== index
                }["ProductImagesUploader[handleRemove > files.filter()]"]);
                const newPreviews = previews.filter({
                    "ProductImagesUploader[handleRemove > previews.filter()]": (__0, i_0)=>i_0 !== index
                }["ProductImagesUploader[handleRemove > previews.filter()]"]);
                setFiles(newFiles);
                setPreviews(newPreviews);
                if (inputRef.current) {
                    const dataTransfer = new DataTransfer();
                    newFiles.forEach({
                        "ProductImagesUploader[handleRemove > newFiles.forEach()]": (file_0)=>dataTransfer.items.add(file_0)
                    }["ProductImagesUploader[handleRemove > newFiles.forEach()]"]);
                    inputRef.current.files = dataTransfer.files;
                }
                if (newPreviews.length === 0) {
                    setPrimaryIndex(-1);
                    return;
                }
                if (index === primaryIndex) {
                    const newIndex = newPreviews.length > 0 ? 0 : -1;
                    setPrimaryIndex(newIndex);
                } else {
                    if (index < primaryIndex) {
                        setPrimaryIndex(_ProductImagesUploaderHandleRemoveSetPrimaryIndex);
                    }
                }
            }
        }["ProductImagesUploader[handleRemove]"];
        let t6;
        if ($[10] !== fieldName) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                id: "product-files",
                name: fieldName,
                type: "file",
                multiple: true,
                accept: "image/*",
                className: "sr-only",
                ref: inputRef,
                onChange: handleChange
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                lineNumber: 99,
                columnNumber: 12
            }, this);
            $[10] = fieldName;
            $[11] = t6;
        } else {
            t6 = $[11];
        }
        let t7;
        if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: "product-files",
                className: "inline-flex cursor-pointer items-center rounded-full bg-zinc-900 px-4 py-2 text-xs font-semibold text-white shadow hover:bg-zinc-800",
                children: "Ajouter des images"
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                lineNumber: 107,
                columnNumber: 12
            }, this);
            $[12] = t7;
        } else {
            t7 = $[12];
        }
        let t8;
        if ($[13] !== primaryIndex) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "hidden",
                name: "primaryIndex",
                value: primaryIndex
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                lineNumber: 114,
                columnNumber: 12
            }, this);
            $[13] = primaryIndex;
            $[14] = t8;
        } else {
            t8 = $[14];
        }
        let t9;
        if ($[15] !== t6 || $[16] !== t8) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3",
                children: [
                    t6,
                    t7,
                    t8
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                lineNumber: 122,
                columnNumber: 12
            }, this);
            $[15] = t6;
            $[16] = t8;
            $[17] = t9;
        } else {
            t9 = $[17];
        }
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-2",
            children: [
                t9,
                (previews.length > 0 || children) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-[11px] text-zinc-500",
                            children: "Cliquez sur une image pour la définir comme principale."
                        }, void 0, false, {
                            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                            lineNumber: 129,
                            columnNumber: 106
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap gap-3",
                            children: [
                                previews.map({
                                    "ProductImagesUploader[previews.map()]": (src, index_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            onClick: {
                                                "ProductImagesUploader[previews.map() > <div>.onClick]": ()=>setPrimaryIndex(index_0)
                                            }["ProductImagesUploader[previews.map() > <div>.onClick]"],
                                            className: `relative h-16 w-16 overflow-hidden rounded-xl border cursor-pointer ${primaryIndex === index_0 ? "border-[#ff1744] ring-2 ring-[#ff1744]" : "border-zinc-200"}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: src,
                                                    alt: `Preview ${index_0 + 1}`,
                                                    className: "h-full w-full object-cover"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                                    lineNumber: 132,
                                                    columnNumber: 246
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: {
                                                        "ProductImagesUploader[previews.map() > <button>.onClick]": (e_1)=>handleRemove(index_0, e_1)
                                                    }["ProductImagesUploader[previews.map() > <button>.onClick]"],
                                                    className: "absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-600/80 text-[9px] text-white hover:bg-red-700",
                                                    children: "×"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                                    lineNumber: 132,
                                                    columnNumber: 333
                                                }, this),
                                                primaryIndex === index_0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "absolute inset-x-0 bottom-0 bg-black/60 text-[9px] font-semibold text-white px-1 py-0.5 text-center",
                                                    children: "Principale"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                                    lineNumber: 134,
                                                    columnNumber: 259
                                                }, this)
                                            ]
                                        }, index_0, true, {
                                            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                            lineNumber: 130,
                                            columnNumber: 72
                                        }, this)
                                }["ProductImagesUploader[previews.map()]"]),
                                children
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                            lineNumber: 129,
                            columnNumber: 206
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                    lineNumber: 129,
                    columnNumber: 79
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
            lineNumber: 129,
            columnNumber: 10
        }, this);
        $[4] = children;
        $[5] = fieldName;
        $[6] = files;
        $[7] = previews;
        $[8] = primaryIndex;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    return t5;
}
_s(ProductImagesUploader, "L/KEYL1XX4qrG+QQdqZaKfhfWek=");
_c = ProductImagesUploader;
function _ProductImagesUploaderHandleRemoveSetPrimaryIndex(prev) {
    return prev - 1;
}
function _ProductImagesUploaderHandleChangeSelectedFilesMap(file) {
    return URL.createObjectURL(file);
}
var _c;
__turbopack_context__.k.register(_c, "ProductImagesUploader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/admin/ExistingProductImagesEditor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ExistingProductImagesEditor",
    ()=>ExistingProductImagesEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ExistingProductImagesEditor(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18);
    if ($[0] !== "dfca5ac1cd18ed0ab8b508c1c8e559aa427ea7faa530d2e699c9381f0f7e250e") {
        for(let $i = 0; $i < 18; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "dfca5ac1cd18ed0ab8b508c1c8e559aa427ea7faa530d2e699c9381f0f7e250e";
    }
    const { images } = t0;
    const [items, setItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(images);
    const [primaryId, setPrimaryId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(images.find(_ExistingProductImagesEditorImagesFind)?.id ?? images[0]?.id ?? null);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const [removedIds, setRemovedIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "ExistingProductImagesEditor[handleSelectPrimary]": (id)=>{
                setPrimaryId(id);
            }
        })["ExistingProductImagesEditor[handleSelectPrimary]"];
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const handleSelectPrimary = t2;
    let t3;
    if ($[3] !== items || $[4] !== primaryId) {
        t3 = ({
            "ExistingProductImagesEditor[handleRemove]": (e, id_0)=>{
                e.preventDefault();
                e.stopPropagation();
                setItems({
                    "ExistingProductImagesEditor[handleRemove > setItems()]": (prev)=>prev.filter({
                            "ExistingProductImagesEditor[handleRemove > setItems() > prev.filter()]": (img_0)=>img_0.id !== id_0
                        }["ExistingProductImagesEditor[handleRemove > setItems() > prev.filter()]"])
                }["ExistingProductImagesEditor[handleRemove > setItems()]"]);
                setRemovedIds({
                    "ExistingProductImagesEditor[handleRemove > setRemovedIds()]": (prev_0)=>prev_0.includes(id_0) ? prev_0 : [
                            ...prev_0,
                            id_0
                        ]
                }["ExistingProductImagesEditor[handleRemove > setRemovedIds()]"]);
                if (primaryId === id_0) {
                    const remaining = items.filter({
                        "ExistingProductImagesEditor[handleRemove > items.filter()]": (img_1)=>img_1.id !== id_0
                    }["ExistingProductImagesEditor[handleRemove > items.filter()]"]);
                    setPrimaryId(remaining[0]?.id ?? null);
                }
            }
        })["ExistingProductImagesEditor[handleRemove]"];
        $[3] = items;
        $[4] = primaryId;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const handleRemove = t3;
    if (items.length === 0 && removedIds.length === 0) {
        return null;
    }
    let t4;
    if ($[6] !== handleRemove || $[7] !== items || $[8] !== primaryId) {
        t4 = items.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: items.map({
                "ExistingProductImagesEditor[items.map()]": (img_2)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative group",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            onClick: {
                                "ExistingProductImagesEditor[items.map() > <div>.onClick]": (e_0)=>{
                                    e_0.preventDefault();
                                    handleSelectPrimary(img_2.id);
                                }
                            }["ExistingProductImagesEditor[items.map() > <div>.onClick]"],
                            className: `relative h-16 w-16 overflow-hidden rounded-xl border cursor-pointer ${img_2.id === primaryId ? "border-[#ff1744] ring-2 ring-[#ff1744]" : "border-zinc-200"}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: img_2.url,
                                    alt: "Image actuelle",
                                    className: "h-full w-full object-cover"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
                                    lineNumber: 86,
                                    columnNumber: 245
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: {
                                        "ExistingProductImagesEditor[items.map() > <button>.onClick]": (e_1)=>handleRemove(e_1, img_2.id)
                                    }["ExistingProductImagesEditor[items.map() > <button>.onClick]"],
                                    className: "absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-600/80 text-[9px] text-white hover:bg-red-700",
                                    children: "×"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
                                    lineNumber: 86,
                                    columnNumber: 328
                                }, this),
                                img_2.id === primaryId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "absolute inset-x-0 bottom-0 bg-black/60 text-[9px] font-semibold text-white px-1 py-0.5 text-center",
                                    children: "Principale"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
                                    lineNumber: 88,
                                    columnNumber: 258
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
                            lineNumber: 81,
                            columnNumber: 109
                        }, this)
                    }, img_2.id, false, {
                        fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
                        lineNumber: 81,
                        columnNumber: 62
                    }, this)
            }["ExistingProductImagesEditor[items.map()]"])
        }, void 0, false);
        $[6] = handleRemove;
        $[7] = items;
        $[8] = primaryId;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    let t5;
    if ($[10] !== primaryId) {
        t5 = primaryId !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "hidden",
            name: "primaryExistingId",
            value: primaryId
        }, void 0, false, {
            fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
            lineNumber: 99,
            columnNumber: 32
        }, this);
        $[10] = primaryId;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    let t6;
    if ($[12] !== removedIds) {
        t6 = removedIds.map(_ExistingProductImagesEditorRemovedIdsMap);
        $[12] = removedIds;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    let t7;
    if ($[14] !== t4 || $[15] !== t5 || $[16] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t4,
                t5,
                t6
            ]
        }, void 0, true);
        $[14] = t4;
        $[15] = t5;
        $[16] = t6;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    return t7;
}
_s(ExistingProductImagesEditor, "A+YEE1xt0FpNdRc/CggYTvzmHfc=");
_c = ExistingProductImagesEditor;
function _ExistingProductImagesEditorRemovedIdsMap(id_1) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: "hidden",
        name: "removeImageIds",
        value: id_1
    }, id_1, false, {
        fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
        lineNumber: 126,
        columnNumber: 10
    }, this);
}
function _ExistingProductImagesEditorImagesFind(img) {
    return img.isPrimary;
}
var _c;
__turbopack_context__.k.register(_c, "ExistingProductImagesEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/admin/ProductFeaturesEditor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductFeaturesEditor",
    ()=>ProductFeaturesEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ProductFeaturesEditor(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20);
    if ($[0] !== "4b0318397014f24594085efbf647312c632a49f39d1a3f969c4b1961cf4893e1") {
        for(let $i = 0; $i < 20; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4b0318397014f24594085efbf647312c632a49f39d1a3f969c4b1961cf4893e1";
    }
    const { images, features } = t0;
    let t1;
    if ($[1] !== features) {
        t1 = features.length > 0 ? features.sort(_ProductFeaturesEditorFeaturesSort).map(_ProductFeaturesEditorAnonymous) : [];
        $[1] = features;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const initialRows = t1;
    let t2;
    if ($[3] !== initialRows) {
        t2 = ({
            "ProductFeaturesEditor[useState()]": ()=>initialRows.map(_ProductFeaturesEditorUseStateInitialRowsMap)
        })["ProductFeaturesEditor[useState()]"];
        $[3] = initialRows;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const [rows, setRows] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    let t4;
    if ($[5] !== rows) {
        t3 = ({
            "ProductFeaturesEditor[useEffect()]": ()=>()=>{
                    rows.forEach(_ProductFeaturesEditorUseEffectAnonymousRowsForEach);
                }
        })["ProductFeaturesEditor[useEffect()]"];
        t4 = [
            rows
        ];
        $[5] = rows;
        $[6] = t3;
        $[7] = t4;
    } else {
        t3 = $[6];
        t4 = $[7];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    const validateImageFile = _ProductFeaturesEditorValidateImageFile;
    let t5;
    if ($[8] !== images[0]?.url) {
        t5 = ({
            "ProductFeaturesEditor[handleAddRow]": ()=>{
                const defaultImageUrl = images[0]?.url ?? "";
                setRows({
                    "ProductFeaturesEditor[handleAddRow > setRows()]": (prev)=>[
                            ...prev,
                            {
                                id: null,
                                imageUrl: defaultImageUrl,
                                _previewUrl: defaultImageUrl,
                                title: "",
                                description: ""
                            }
                        ]
                }["ProductFeaturesEditor[handleAddRow > setRows()]"]);
            }
        })["ProductFeaturesEditor[handleAddRow]"];
        $[8] = images[0]?.url;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    const handleAddRow = t5;
    let t6;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "ProductFeaturesEditor[handleRemoveRow]": (index)=>{
                setRows({
                    "ProductFeaturesEditor[handleRemoveRow > setRows()]": (prev_0)=>prev_0.filter({
                            "ProductFeaturesEditor[handleRemoveRow > setRows() > prev_0.filter()]": (_, i)=>i !== index
                        }["ProductFeaturesEditor[handleRemoveRow > setRows() > prev_0.filter()]"])
                }["ProductFeaturesEditor[handleRemoveRow > setRows()]"]);
            }
        })["ProductFeaturesEditor[handleRemoveRow]"];
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    const handleRemoveRow = t6;
    if (images.length === 0) {
        let t7;
        if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs text-zinc-500",
                children: "Ajoutez d'abord des images produit pour pouvoir créer des caractéristiques visuelles."
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                lineNumber: 119,
                columnNumber: 12
            }, this);
            $[11] = t7;
        } else {
            t7 = $[11];
        }
        return t7;
    }
    let t7;
    if ($[12] !== rows) {
        t7 = rows.map({
            "ProductFeaturesEditor[rows.map()]": (row_1, index_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-3 rounded-xl border border-zinc-200 bg-zinc-50/60 p-3 md:flex-row md:items-start md:gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-full md:w-1/3 space-y-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-[11px] font-medium text-zinc-700",
                                    children: "Image de la caractéristique"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                    lineNumber: 129,
                                    columnNumber: 246
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "hidden",
                                    name: "featureImageUrls",
                                    value: row_1.imageUrl
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                    lineNumber: 129,
                                    columnNumber: 338
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    id: `featureNewImage_${index_0}`,
                                    type: "file",
                                    name: `featureNewImage_${index_0}`,
                                    accept: "image/*",
                                    className: "hidden",
                                    onChange: {
                                        "ProductFeaturesEditor[rows.map() > <input>.onChange]": (e)=>{
                                            const file_0 = e.target.files?.[0];
                                            if (!file_0) {
                                                return;
                                            }
                                            if (!validateImageFile(file_0)) {
                                                e.target.value = "";
                                                return;
                                            }
                                            const previewUrl = URL.createObjectURL(file_0);
                                            const prevRow = rows[index_0];
                                            if (prevRow?._previewUrl && prevRow._previewUrl.startsWith("blob:")) {
                                                URL.revokeObjectURL(prevRow._previewUrl);
                                            }
                                            setRows({
                                                "ProductFeaturesEditor[rows.map() > <input>.onChange > setRows()]": (prev_1)=>prev_1.map({
                                                        "ProductFeaturesEditor[rows.map() > <input>.onChange > setRows() > prev_1.map()]": (r, i_0)=>i_0 === index_0 ? {
                                                                ...r,
                                                                _file: file_0,
                                                                _previewUrl: previewUrl,
                                                                imageUrl: ""
                                                            } : r
                                                    }["ProductFeaturesEditor[rows.map() > <input>.onChange > setRows() > prev_1.map()]"])
                                            }["ProductFeaturesEditor[rows.map() > <input>.onChange > setRows()]"]);
                                        }
                                    }["ProductFeaturesEditor[rows.map() > <input>.onChange]"]
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                    lineNumber: 129,
                                    columnNumber: 408
                                }, this),
                                row_1._previewUrl || row_1.imageUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative h-32 w-32 rounded-3xl border border-zinc-200 bg-white shadow-sm flex items-center justify-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            htmlFor: `featureNewImage_${index_0}`,
                                            className: "h-24 w-24 overflow-hidden rounded-2xl bg-zinc-50 cursor-pointer",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: row_1._previewUrl || row_1.imageUrl,
                                                alt: row_1.title || "Image caract\xE9ristique",
                                                className: "h-full w-full object-cover",
                                                onError: _ProductFeaturesEditorRowsMapImgOnError
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                                lineNumber: 155,
                                                columnNumber: 356
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                            lineNumber: 155,
                                            columnNumber: 234
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: {
                                                "ProductFeaturesEditor[rows.map() > <button>.onClick]": ()=>{
                                                    setRows({
                                                        "ProductFeaturesEditor[rows.map() > <button>.onClick > setRows()]": (prev_2)=>prev_2.map({
                                                                "ProductFeaturesEditor[rows.map() > <button>.onClick > setRows() > prev_2.map()]": (r_0, i_1)=>i_1 === index_0 ? {
                                                                        ...r_0,
                                                                        imageUrl: "",
                                                                        _previewUrl: "",
                                                                        _file: undefined
                                                                    } : r_0
                                                            }["ProductFeaturesEditor[rows.map() > <button>.onClick > setRows() > prev_2.map()]"])
                                                    }["ProductFeaturesEditor[rows.map() > <button>.onClick > setRows()]"]);
                                                }
                                            }["ProductFeaturesEditor[rows.map() > <button>.onClick]"],
                                            className: "absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-[11px] font-semibold text-white shadow-md hover:bg-red-600",
                                            "aria-label": "Retirer l'image de cette caract\xE9ristique",
                                            children: "×"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                            lineNumber: 155,
                                            columnNumber: 550
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                    lineNumber: 155,
                                    columnNumber: 111
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "pt-1",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: `featureNewImage_${index_0}`,
                                        className: "flex cursor-pointer items-center gap-2 rounded-xl border border-dashed border-red-200 bg-red-50/60 px-3 py-2 text-[10px] text-red-700 hover:bg-red-100 hover:border-red-300",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-[12px] font-bold text-white",
                                                children: "+"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                                lineNumber: 168,
                                                columnNumber: 568
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex flex-col",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-semibold",
                                                        children: "Ajouter une image"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                                        lineNumber: 168,
                                                        columnNumber: 724
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[9px] text-red-500/80",
                                                        children: "Depuis votre ordinateur (JPG, PNG, WebP, GIF…)"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                                        lineNumber: 168,
                                                        columnNumber: 780
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                                lineNumber: 168,
                                                columnNumber: 692
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                        lineNumber: 168,
                                        columnNumber: 338
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                    lineNumber: 168,
                                    columnNumber: 316
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                            lineNumber: 129,
                            columnNumber: 203
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-full md:flex-1 space-y-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-[11px] font-medium text-zinc-700",
                                            children: "Titre de la caractéristique"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                            lineNumber: 168,
                                            columnNumber: 977
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "text",
                                            name: "featureTitles",
                                            value: row_1.title,
                                            onChange: {
                                                "ProductFeaturesEditor[rows.map() > <input>.onChange]": (e_1)=>{
                                                    const value = e_1.target.value;
                                                    setRows({
                                                        "ProductFeaturesEditor[rows.map() > <input>.onChange > setRows()]": (prev_3)=>prev_3.map({
                                                                "ProductFeaturesEditor[rows.map() > <input>.onChange > setRows() > prev_3.map()]": (r_1, i_2)=>i_2 === index_0 ? {
                                                                        ...r_1,
                                                                        title: value
                                                                    } : r_1
                                                            }["ProductFeaturesEditor[rows.map() > <input>.onChange > setRows() > prev_3.map()]"])
                                                    }["ProductFeaturesEditor[rows.map() > <input>.onChange > setRows()]"]);
                                                }
                                            }["ProductFeaturesEditor[rows.map() > <input>.onChange]"],
                                            className: "w-full rounded-md border border-zinc-300 px-3 py-2 text-xs outline-none focus:border-zinc-900",
                                            placeholder: `Caractéristique ${index_0 + 1}`
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                            lineNumber: 168,
                                            columnNumber: 1069
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                    lineNumber: 168,
                                    columnNumber: 950
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-[11px] font-medium text-zinc-700",
                                            children: "Paragraphe de la caractéristique"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                            lineNumber: 180,
                                            columnNumber: 260
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                            name: "featureDescriptions",
                                            value: row_1.description,
                                            onChange: {
                                                "ProductFeaturesEditor[rows.map() > <textarea>.onChange]": (e_2)=>{
                                                    const value_0 = e_2.target.value;
                                                    setRows({
                                                        "ProductFeaturesEditor[rows.map() > <textarea>.onChange > setRows()]": (prev_4)=>prev_4.map({
                                                                "ProductFeaturesEditor[rows.map() > <textarea>.onChange > setRows() > prev_4.map()]": (r_2, i_3)=>i_3 === index_0 ? {
                                                                        ...r_2,
                                                                        description: value_0
                                                                    } : r_2
                                                            }["ProductFeaturesEditor[rows.map() > <textarea>.onChange > setRows() > prev_4.map()]"])
                                                    }["ProductFeaturesEditor[rows.map() > <textarea>.onChange > setRows()]"]);
                                                }
                                            }["ProductFeaturesEditor[rows.map() > <textarea>.onChange]"],
                                            className: "w-full rounded-md border border-zinc-300 px-3 py-2 text-xs outline-none focus:border-zinc-900",
                                            rows: 2
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                            lineNumber: 180,
                                            columnNumber: 357
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                    lineNumber: 180,
                                    columnNumber: 233
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                            lineNumber: 168,
                            columnNumber: 906
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-end md:pt-6",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: {
                                    "ProductFeaturesEditor[rows.map() > <button>.onClick]": ()=>handleRemoveRow(index_0)
                                }["ProductFeaturesEditor[rows.map() > <button>.onClick]"],
                                className: "text-[11px] text-red-600 hover:text-red-700",
                                children: "Supprimer"
                            }, void 0, false, {
                                fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                                lineNumber: 192,
                                columnNumber: 246
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                            lineNumber: 192,
                            columnNumber: 204
                        }, this)
                    ]
                }, index_0, true, {
                    fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                    lineNumber: 129,
                    columnNumber: 64
                }, this)
        }["ProductFeaturesEditor[rows.map()]"]);
        $[12] = rows;
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    let t8;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-[11px] text-zinc-500",
            children: "Vous pouvez ajouter plusieurs caractéristiques. Elles seront affichées dans l'ordre de la liste."
        }, void 0, false, {
            fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
            lineNumber: 203,
            columnNumber: 10
        }, this);
        $[14] = t8;
    } else {
        t8 = $[14];
    }
    let t9;
    if ($[15] !== handleAddRow) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-between items-center pt-1",
            children: [
                t8,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    onClick: handleAddRow,
                    className: "inline-flex items-center rounded-full bg-zinc-900 px-3 py-1.5 text-[11px] font-medium text-white hover:bg-zinc-800",
                    children: "+ Ajouter une caractéristique"
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
                    lineNumber: 210,
                    columnNumber: 70
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
            lineNumber: 210,
            columnNumber: 10
        }, this);
        $[15] = handleAddRow;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    let t10;
    if ($[17] !== t7 || $[18] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-4",
            children: [
                t7,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/ProductFeaturesEditor.tsx",
            lineNumber: 218,
            columnNumber: 11
        }, this);
        $[17] = t7;
        $[18] = t9;
        $[19] = t10;
    } else {
        t10 = $[19];
    }
    return t10;
}
_s(ProductFeaturesEditor, "ytsKjXkGdY8Esrw+TmNEcEjNDTU=");
_c = ProductFeaturesEditor;
function _ProductFeaturesEditorRowsMapImgOnError(e_0) {
    const target = e_0.target;
    target.style.display = "none";
}
function _ProductFeaturesEditorValidateImageFile(file) {
    const validTypes = [
        "image/jpeg",
        "image/png",
        "image/webp",
        "image/gif"
    ];
    if (!validTypes.includes(file.type)) {
        alert("Veuillez s\xE9lectionner une image au format JPG, PNG, WebP ou GIF.");
        return false;
    }
    if (file.size > 5242880) {
        alert("La taille de l'image ne doit pas d\xE9passer 5 Mo.");
        return false;
    }
    return true;
}
function _ProductFeaturesEditorUseEffectAnonymousRowsForEach(row_0) {
    if (row_0._previewUrl && row_0._previewUrl.startsWith("blob:")) {
        URL.revokeObjectURL(row_0._previewUrl);
    }
}
function _ProductFeaturesEditorUseStateInitialRowsMap(row) {
    return {
        ...row,
        _previewUrl: row.imageUrl.startsWith("blob:") ? "" : row.imageUrl
    };
}
function _ProductFeaturesEditorAnonymous(f) {
    return {
        id: f.id,
        imageUrl: f.imageUrl?.startsWith("blob:") ? "" : f.imageUrl,
        title: f.title,
        description: f.description
    };
}
function _ProductFeaturesEditorFeaturesSort(a, b) {
    return a.order - b.order;
}
var _c;
__turbopack_context__.k.register(_c, "ProductFeaturesEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_admin_ab356ab0._.js.map