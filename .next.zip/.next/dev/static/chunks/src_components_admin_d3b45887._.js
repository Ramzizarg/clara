(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/admin/SignOutButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SignOutButton",
    ()=>SignOutButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/log-out.js [app-client] (ecmascript) <export default as LogOut>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react/index.js [app-client] (ecmascript)");
"use client";
;
;
;
;
function SignOutButton() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "6f47cc9d1497d26000a74a535e77296bfb88e60280d763f2d63945e78b0bc887") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6f47cc9d1497d26000a74a535e77296bfb88e60280d763f2d63945e78b0bc887";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: _SignOutButtonButtonOnClick,
            className: "inline-flex items-center gap-2 rounded-full border border-zinc-300 px-4 py-1 text-xs font-medium text-zinc-100 hover:bg-white/5 hover:border-zinc-100 transition-colors",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__["LogOut"], {
                    className: "h-4 w-4 text-zinc-100"
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/SignOutButton.tsx",
                    lineNumber: 16,
                    columnNumber: 250
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: "Déconnexion"
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/SignOutButton.tsx",
                    lineNumber: 16,
                    columnNumber: 294
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/SignOutButton.tsx",
            lineNumber: 16,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c = SignOutButton;
function _SignOutButtonButtonOnClick() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signOut"])({
        callbackUrl: "/login"
    });
}
var _c;
__turbopack_context__.k.register(_c, "SignOutButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/admin/ProductImagesUploader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductImagesUploader",
    ()=>ProductImagesUploader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ProductImagesUploader(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "1de1f3a4096ad69c5a48a66d6e76f11e985dddce94d4abe392508f405ad65a08") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "1de1f3a4096ad69c5a48a66d6e76f11e985dddce94d4abe392508f405ad65a08";
    }
    const { fieldName: t1 } = t0;
    const fieldName = t1 === undefined ? "files" : t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [];
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    const [previews, setPreviews] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    const [primaryIndex, setPrimaryIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    let t3;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "ProductImagesUploader[handleChange]": (e)=>{
                const files = e.target.files;
                if (!files || files.length === 0) {
                    setPreviews([]);
                    setPrimaryIndex(0);
                    return;
                }
                const urls = [];
                for(let i = 0; i < files.length; i++){
                    const file = files[i];
                    urls.push(URL.createObjectURL(file));
                }
                setPreviews(urls);
                setPrimaryIndex(0);
            }
        })["ProductImagesUploader[handleChange]"];
        $[2] = t3;
    } else {
        t3 = $[2];
    }
    const handleChange = t3;
    let t4;
    if ($[3] !== fieldName) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            id: "product-files",
            name: fieldName,
            type: "file",
            multiple: true,
            accept: "image/*",
            className: "sr-only",
            onChange: handleChange
        }, void 0, false, {
            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
            lineNumber: 55,
            columnNumber: 10
        }, this);
        $[3] = fieldName;
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    let t5;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            htmlFor: "product-files",
            className: "inline-flex cursor-pointer items-center rounded-full bg-zinc-900 px-4 py-2 text-xs font-semibold text-white shadow hover:bg-zinc-800",
            children: "Ajouter des images"
        }, void 0, false, {
            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
            lineNumber: 63,
            columnNumber: 10
        }, this);
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    let t6;
    if ($[6] !== primaryIndex) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "hidden",
            name: "primaryIndex",
            value: primaryIndex
        }, void 0, false, {
            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
            lineNumber: 70,
            columnNumber: 10
        }, this);
        $[6] = primaryIndex;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] !== t4 || $[9] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-3",
            children: [
                t4,
                t5,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
            lineNumber: 78,
            columnNumber: 10
        }, this);
        $[8] = t4;
        $[9] = t6;
        $[10] = t7;
    } else {
        t7 = $[10];
    }
    let t8;
    if ($[11] !== previews || $[12] !== primaryIndex) {
        t8 = previews.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-[11px] text-zinc-500",
                    children: "Cliquez sur une image pour la définir comme principale."
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                    lineNumber: 87,
                    columnNumber: 60
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-wrap gap-3",
                    children: previews.map({
                        "ProductImagesUploader[previews.map()]": (src, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: {
                                    "ProductImagesUploader[previews.map() > <button>.onClick]": ()=>setPrimaryIndex(index)
                                }["ProductImagesUploader[previews.map() > <button>.onClick]"],
                                className: `relative h-16 w-16 overflow-hidden rounded-xl border ${primaryIndex === index ? "border-[#ff1744] ring-2 ring-[#ff1744]" : "border-zinc-200"}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: src,
                                        alt: `Preview ${index + 1}`,
                                        className: "h-full w-full object-cover"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                        lineNumber: 90,
                                        columnNumber: 230
                                    }, this),
                                    primaryIndex === index && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute inset-x-0 bottom-0 bg-black/60 text-[9px] font-semibold text-white px-1 py-0.5 text-center",
                                        children: "Principale"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                        lineNumber: 90,
                                        columnNumber: 342
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                lineNumber: 88,
                                columnNumber: 68
                            }, this)
                    }["ProductImagesUploader[previews.map()]"])
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                    lineNumber: 87,
                    columnNumber: 160
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
            lineNumber: 87,
            columnNumber: 33
        }, this);
        $[11] = previews;
        $[12] = primaryIndex;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[14] !== t7 || $[15] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-2",
            children: [
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
            lineNumber: 100,
            columnNumber: 10
        }, this);
        $[14] = t7;
        $[15] = t8;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    return t9;
}
_s(ProductImagesUploader, "buaSiI/aMf0hT1h9gFFskkS55iE=");
_c = ProductImagesUploader;
var _c;
__turbopack_context__.k.register(_c, "ProductImagesUploader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/admin/ExistingImagesManager.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ExistingImagesManager",
    ()=>ExistingImagesManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ExistingImagesManager(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(37);
    if ($[0] !== "500da7cef07fe8232c97ab6461a607be9f825354882473d69ee2c83ae7fdcaf1") {
        for(let $i = 0; $i < 37; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "500da7cef07fe8232c97ab6461a607be9f825354882473d69ee2c83ae7fdcaf1";
    }
    const { images, productName } = t0;
    let t1;
    if ($[1] !== images) {
        t1 = ({
            "ExistingImagesManager[useState()]": ()=>{
                const current = images.find(_ExistingImagesManagerUseStateImagesFind);
                return current ? current.id : images[0]?.id ?? null;
            }
        })["ExistingImagesManager[useState()]"];
        $[1] = images;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [primaryId, setPrimaryId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    const [deletedIds, setDeletedIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(_ExistingImagesManagerUseState);
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "ExistingImagesManager[toggleDelete]": (id)=>{
                setDeletedIds({
                    "ExistingImagesManager[toggleDelete > setDeletedIds()]": (prev)=>{
                        const next = new Set(prev);
                        if (next.has(id)) {
                            next.delete(id);
                        } else {
                            next.add(id);
                        }
                        return next;
                    }
                }["ExistingImagesManager[toggleDelete > setDeletedIds()]"]);
            }
        })["ExistingImagesManager[toggleDelete]"];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const toggleDelete = t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[4] !== deletedIds || $[5] !== images || $[6] !== primaryId || $[7] !== productName) {
        let t10;
        if ($[15] !== deletedIds) {
            t10 = ({
                "ExistingImagesManager[images.filter()]": (img_0)=>!deletedIds.has(img_0.id)
            })["ExistingImagesManager[images.filter()]"];
            $[15] = deletedIds;
            $[16] = t10;
        } else {
            t10 = $[16];
        }
        const visibleImages = images.filter(t10);
        t5 = "space-y-2";
        if ($[17] !== primaryId) {
            t6 = primaryId !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "hidden",
                name: "existingPrimaryId",
                value: primaryId
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ExistingImagesManager.tsx",
                lineNumber: 84,
                columnNumber: 34
            }, this);
            $[17] = primaryId;
            $[18] = t6;
        } else {
            t6 = $[18];
        }
        if ($[19] !== deletedIds) {
            t7 = [
                ...deletedIds
            ].map(_ExistingImagesManagerAnonymous);
            $[19] = deletedIds;
            $[20] = t7;
        } else {
            t7 = $[20];
        }
        if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs font-semibold text-zinc-700",
                children: "Images actuelles"
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ExistingImagesManager.tsx",
                lineNumber: 98,
                columnNumber: 12
            }, this);
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-[11px] text-zinc-500",
                children: "Cliquez sur une image pour la définir comme principale. Utilisez l'ic\0f4ne de suppression pour retirer une image."
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ExistingImagesManager.tsx",
                lineNumber: 99,
                columnNumber: 12
            }, this);
            $[21] = t8;
            $[22] = t9;
        } else {
            t8 = $[21];
            t9 = $[22];
        }
        t3 = "flex flex-wrap gap-3";
        let t11;
        if ($[23] !== deletedIds || $[24] !== primaryId || $[25] !== productName) {
            t11 = ({
                "ExistingImagesManager[visibleImages.map()]": (img_1)=>{
                    const isPrimary = img_1.id === primaryId;
                    const isDeleted = deletedIds.has(img_1.id);
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `relative h-20 w-20 overflow-hidden rounded-xl border transition-all cursor-pointer ${isPrimary ? "border-[#ff1744] ring-2 ring-[#ff1744]" : "border-zinc-200 hover:border-zinc-400"}`,
                        onClick: {
                            "ExistingImagesManager[visibleImages.map() > <div>.onClick]": ()=>{
                                if (!isDeleted) {
                                    setPrimaryId(img_1.id);
                                }
                            }
                        }["ExistingImagesManager[visibleImages.map() > <div>.onClick]"],
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: img_1.url,
                                alt: productName,
                                className: "h-full w-full object-cover"
                            }, void 0, false, {
                                fileName: "[project]/src/components/admin/ExistingImagesManager.tsx",
                                lineNumber: 119,
                                columnNumber: 76
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute left-1 top-1 flex h-4 w-4 items-center justify-center rounded-full border border-white bg-black/40",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `h-2.5 w-2.5 rounded-full ${isPrimary ? "bg-[#ff1744]" : "bg-white/70"}`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/ExistingImagesManager.tsx",
                                    lineNumber: 119,
                                    columnNumber: 281
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/admin/ExistingImagesManager.tsx",
                                lineNumber: 119,
                                columnNumber: 156
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: {
                                    "ExistingImagesManager[visibleImages.map() > <button>.onClick]": (e)=>{
                                        e.stopPropagation();
                                        toggleDelete(img_1.id);
                                    }
                                }["ExistingImagesManager[visibleImages.map() > <button>.onClick]"],
                                className: "absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-black/70 text-[9px] font-bold text-white hover:bg-black",
                                children: "\0d7"
                            }, void 0, false, {
                                fileName: "[project]/src/components/admin/ExistingImagesManager.tsx",
                                lineNumber: 119,
                                columnNumber: 379
                            }, this),
                            isPrimary && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "absolute inset-x-0 bottom-0 bg-black/60 text-[9px] font-semibold text-white px-1 py-0.5 text-center",
                                children: "Principale"
                            }, void 0, false, {
                                fileName: "[project]/src/components/admin/ExistingImagesManager.tsx",
                                lineNumber: 124,
                                columnNumber: 255
                            }, this)
                        ]
                    }, img_1.id, true, {
                        fileName: "[project]/src/components/admin/ExistingImagesManager.tsx",
                        lineNumber: 113,
                        columnNumber: 18
                    }, this);
                }
            })["ExistingImagesManager[visibleImages.map()]"];
            $[23] = deletedIds;
            $[24] = primaryId;
            $[25] = productName;
            $[26] = t11;
        } else {
            t11 = $[26];
        }
        t4 = visibleImages.map(t11);
        $[4] = deletedIds;
        $[5] = images;
        $[6] = primaryId;
        $[7] = productName;
        $[8] = t3;
        $[9] = t4;
        $[10] = t5;
        $[11] = t6;
        $[12] = t7;
        $[13] = t8;
        $[14] = t9;
    } else {
        t3 = $[8];
        t4 = $[9];
        t5 = $[10];
        t6 = $[11];
        t7 = $[12];
        t8 = $[13];
        t9 = $[14];
    }
    let t10;
    if ($[27] !== t3 || $[28] !== t4) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t3,
            children: t4
        }, void 0, false, {
            fileName: "[project]/src/components/admin/ExistingImagesManager.tsx",
            lineNumber: 157,
            columnNumber: 11
        }, this);
        $[27] = t3;
        $[28] = t4;
        $[29] = t10;
    } else {
        t10 = $[29];
    }
    let t11;
    if ($[30] !== t10 || $[31] !== t5 || $[32] !== t6 || $[33] !== t7 || $[34] !== t8 || $[35] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t5,
            children: [
                t6,
                t7,
                t8,
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/ExistingImagesManager.tsx",
            lineNumber: 166,
            columnNumber: 11
        }, this);
        $[30] = t10;
        $[31] = t5;
        $[32] = t6;
        $[33] = t7;
        $[34] = t8;
        $[35] = t9;
        $[36] = t11;
    } else {
        t11 = $[36];
    }
    return t11;
}
_s(ExistingImagesManager, "827xXvNH6Bm3R43ab2YJJmqcEpg=");
_c = ExistingImagesManager;
function _ExistingImagesManagerAnonymous(id_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: "hidden",
        name: "deleteImageIds",
        value: id_0
    }, id_0, false, {
        fileName: "[project]/src/components/admin/ExistingImagesManager.tsx",
        lineNumber: 180,
        columnNumber: 10
    }, this);
}
function _ExistingImagesManagerUseState() {
    return new Set();
}
function _ExistingImagesManagerUseStateImagesFind(img) {
    return img.isPrimary;
}
var _c;
__turbopack_context__.k.register(_c, "ExistingImagesManager");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_admin_d3b45887._.js.map