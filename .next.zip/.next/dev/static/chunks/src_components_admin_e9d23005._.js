(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/admin/SignOutButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SignOutButton",
    ()=>SignOutButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/log-out.js [app-client] (ecmascript) <export default as LogOut>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react/index.js [app-client] (ecmascript)");
"use client";
;
;
;
;
function SignOutButton() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "6f47cc9d1497d26000a74a535e77296bfb88e60280d763f2d63945e78b0bc887") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6f47cc9d1497d26000a74a535e77296bfb88e60280d763f2d63945e78b0bc887";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: _SignOutButtonButtonOnClick,
            className: "inline-flex items-center gap-2 rounded-full border border-zinc-300 px-4 py-1 text-xs font-medium text-zinc-100 hover:bg-white/5 hover:border-zinc-100 transition-colors",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__["LogOut"], {
                    className: "h-4 w-4 text-zinc-100"
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/SignOutButton.tsx",
                    lineNumber: 16,
                    columnNumber: 250
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: "Déconnexion"
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/SignOutButton.tsx",
                    lineNumber: 16,
                    columnNumber: 294
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/SignOutButton.tsx",
            lineNumber: 16,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c = SignOutButton;
function _SignOutButtonButtonOnClick() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signOut"])({
        callbackUrl: "/login"
    });
}
var _c;
__turbopack_context__.k.register(_c, "SignOutButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/admin/ProductImagesUploader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductImagesUploader",
    ()=>ProductImagesUploader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ProductImagesUploader(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18);
    if ($[0] !== "d87ec984c14e7687967b4eb5db1da79a84b51c74cd25d74801e6ed4b56f08ec9") {
        for(let $i = 0; $i < 18; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d87ec984c14e7687967b4eb5db1da79a84b51c74cd25d74801e6ed4b56f08ec9";
    }
    const { fieldName: t1, children } = t0;
    const fieldName = t1 === undefined ? "files" : t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [];
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    const [previews, setPreviews] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = [];
        $[2] = t3;
    } else {
        t3 = $[2];
    }
    const [files, setFiles] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t3);
    const [primaryIndex, setPrimaryIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t4;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "ProductImagesUploader[handleChange]": (e)=>{
                const files_0 = e.target.files;
                if (!files_0 || files_0.length === 0) {
                    setPreviews([]);
                    setFiles([]);
                    setPrimaryIndex(-1);
                    return;
                }
                const selectedFiles = Array.from(files_0);
                const urls = selectedFiles.map(_ProductImagesUploaderHandleChangeSelectedFilesMap);
                setFiles(selectedFiles);
                setPreviews(urls);
                setPrimaryIndex(-1);
            }
        })["ProductImagesUploader[handleChange]"];
        $[3] = t4;
    } else {
        t4 = $[3];
    }
    const handleChange = t4;
    let t5;
    if ($[4] !== children || $[5] !== fieldName || $[6] !== files || $[7] !== previews || $[8] !== primaryIndex) {
        const handleRemove = {
            "ProductImagesUploader[handleRemove]": (index, e_0)=>{
                e_0.stopPropagation();
                const newFiles = files.filter({
                    "ProductImagesUploader[handleRemove > files.filter()]": (_, i)=>i !== index
                }["ProductImagesUploader[handleRemove > files.filter()]"]);
                const newPreviews = previews.filter({
                    "ProductImagesUploader[handleRemove > previews.filter()]": (__0, i_0)=>i_0 !== index
                }["ProductImagesUploader[handleRemove > previews.filter()]"]);
                setFiles(newFiles);
                setPreviews(newPreviews);
                if (inputRef.current) {
                    const dataTransfer = new DataTransfer();
                    newFiles.forEach({
                        "ProductImagesUploader[handleRemove > newFiles.forEach()]": (file_0)=>dataTransfer.items.add(file_0)
                    }["ProductImagesUploader[handleRemove > newFiles.forEach()]"]);
                    inputRef.current.files = dataTransfer.files;
                }
                if (newPreviews.length === 0) {
                    setPrimaryIndex(-1);
                    return;
                }
                if (index === primaryIndex) {
                    const newIndex = newPreviews.length > 0 ? 0 : -1;
                    setPrimaryIndex(newIndex);
                } else {
                    if (index < primaryIndex) {
                        setPrimaryIndex(_ProductImagesUploaderHandleRemoveSetPrimaryIndex);
                    }
                }
            }
        }["ProductImagesUploader[handleRemove]"];
        let t6;
        if ($[10] !== fieldName) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                id: "product-files",
                name: fieldName,
                type: "file",
                multiple: true,
                accept: "image/*",
                className: "sr-only",
                ref: inputRef,
                onChange: handleChange
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                lineNumber: 99,
                columnNumber: 12
            }, this);
            $[10] = fieldName;
            $[11] = t6;
        } else {
            t6 = $[11];
        }
        let t7;
        if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: "product-files",
                className: "inline-flex cursor-pointer items-center rounded-full bg-zinc-900 px-4 py-2 text-xs font-semibold text-white shadow hover:bg-zinc-800",
                children: "Ajouter des images"
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                lineNumber: 107,
                columnNumber: 12
            }, this);
            $[12] = t7;
        } else {
            t7 = $[12];
        }
        let t8;
        if ($[13] !== primaryIndex) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "hidden",
                name: "primaryIndex",
                value: primaryIndex
            }, void 0, false, {
                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                lineNumber: 114,
                columnNumber: 12
            }, this);
            $[13] = primaryIndex;
            $[14] = t8;
        } else {
            t8 = $[14];
        }
        let t9;
        if ($[15] !== t6 || $[16] !== t8) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3",
                children: [
                    t6,
                    t7,
                    t8
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                lineNumber: 122,
                columnNumber: 12
            }, this);
            $[15] = t6;
            $[16] = t8;
            $[17] = t9;
        } else {
            t9 = $[17];
        }
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-2",
            children: [
                t9,
                (previews.length > 0 || children) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-[11px] text-zinc-500",
                            children: "Cliquez sur une image pour la définir comme principale."
                        }, void 0, false, {
                            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                            lineNumber: 129,
                            columnNumber: 106
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap gap-3",
                            children: [
                                previews.map({
                                    "ProductImagesUploader[previews.map()]": (src, index_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            onClick: {
                                                "ProductImagesUploader[previews.map() > <div>.onClick]": ()=>setPrimaryIndex(index_0)
                                            }["ProductImagesUploader[previews.map() > <div>.onClick]"],
                                            className: `relative h-16 w-16 overflow-hidden rounded-xl border cursor-pointer ${primaryIndex === index_0 ? "border-[#ff1744] ring-2 ring-[#ff1744]" : "border-zinc-200"}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: src,
                                                    alt: `Preview ${index_0 + 1}`,
                                                    className: "h-full w-full object-cover"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                                    lineNumber: 132,
                                                    columnNumber: 246
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: {
                                                        "ProductImagesUploader[previews.map() > <button>.onClick]": (e_1)=>handleRemove(index_0, e_1)
                                                    }["ProductImagesUploader[previews.map() > <button>.onClick]"],
                                                    className: "absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-600/80 text-[9px] text-white hover:bg-red-700",
                                                    children: "×"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                                    lineNumber: 132,
                                                    columnNumber: 333
                                                }, this),
                                                primaryIndex === index_0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "absolute inset-x-0 bottom-0 bg-black/60 text-[9px] font-semibold text-white px-1 py-0.5 text-center",
                                                    children: "Principale"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                                    lineNumber: 134,
                                                    columnNumber: 259
                                                }, this)
                                            ]
                                        }, index_0, true, {
                                            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                                            lineNumber: 130,
                                            columnNumber: 72
                                        }, this)
                                }["ProductImagesUploader[previews.map()]"]),
                                children
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                            lineNumber: 129,
                            columnNumber: 206
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
                    lineNumber: 129,
                    columnNumber: 79
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/ProductImagesUploader.tsx",
            lineNumber: 129,
            columnNumber: 10
        }, this);
        $[4] = children;
        $[5] = fieldName;
        $[6] = files;
        $[7] = previews;
        $[8] = primaryIndex;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    return t5;
}
_s(ProductImagesUploader, "L/KEYL1XX4qrG+QQdqZaKfhfWek=");
_c = ProductImagesUploader;
function _ProductImagesUploaderHandleRemoveSetPrimaryIndex(prev) {
    return prev - 1;
}
function _ProductImagesUploaderHandleChangeSelectedFilesMap(file) {
    return URL.createObjectURL(file);
}
var _c;
__turbopack_context__.k.register(_c, "ProductImagesUploader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/admin/ExistingProductImagesEditor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ExistingProductImagesEditor",
    ()=>ExistingProductImagesEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ExistingProductImagesEditor(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18);
    if ($[0] !== "a882e9396451b6e73894d55d6bf95b98f7e66231d785f65b1690d1c218e8a0d1") {
        for(let $i = 0; $i < 18; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a882e9396451b6e73894d55d6bf95b98f7e66231d785f65b1690d1c218e8a0d1";
    }
    const { images } = t0;
    const [items, setItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(images);
    const [primaryId, setPrimaryId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(images.find(_ExistingProductImagesEditorImagesFind)?.id ?? images[0]?.id ?? null);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const [removedIds, setRemovedIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "ExistingProductImagesEditor[handleSelectPrimary]": (id)=>{
                setPrimaryId(id);
            }
        })["ExistingProductImagesEditor[handleSelectPrimary]"];
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const handleSelectPrimary = t2;
    let t3;
    if ($[3] !== items || $[4] !== primaryId) {
        t3 = ({
            "ExistingProductImagesEditor[handleRemove]": (id_0, e)=>{
                e.stopPropagation();
                setItems({
                    "ExistingProductImagesEditor[handleRemove > setItems()]": (prev)=>prev.filter({
                            "ExistingProductImagesEditor[handleRemove > setItems() > prev.filter()]": (img_0)=>img_0.id !== id_0
                        }["ExistingProductImagesEditor[handleRemove > setItems() > prev.filter()]"])
                }["ExistingProductImagesEditor[handleRemove > setItems()]"]);
                setRemovedIds({
                    "ExistingProductImagesEditor[handleRemove > setRemovedIds()]": (prev_0)=>prev_0.includes(id_0) ? prev_0 : [
                            ...prev_0,
                            id_0
                        ]
                }["ExistingProductImagesEditor[handleRemove > setRemovedIds()]"]);
                if (primaryId === id_0) {
                    const remaining = items.filter({
                        "ExistingProductImagesEditor[handleRemove > items.filter()]": (img_1)=>img_1.id !== id_0
                    }["ExistingProductImagesEditor[handleRemove > items.filter()]"]);
                    setPrimaryId(remaining[0]?.id ?? null);
                }
            }
        })["ExistingProductImagesEditor[handleRemove]"];
        $[3] = items;
        $[4] = primaryId;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const handleRemove = t3;
    if (items.length === 0 && removedIds.length === 0) {
        return null;
    }
    let t4;
    if ($[6] !== handleRemove || $[7] !== items || $[8] !== primaryId) {
        t4 = items.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: items.map({
                "ExistingProductImagesEditor[items.map()]": (img_2)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative group",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            onClick: {
                                "ExistingProductImagesEditor[items.map() > <div>.onClick]": ()=>handleSelectPrimary(img_2.id)
                            }["ExistingProductImagesEditor[items.map() > <div>.onClick]"],
                            className: `relative h-16 w-16 overflow-hidden rounded-xl border cursor-pointer ${img_2.id === primaryId ? "border-[#ff1744] ring-2 ring-[#ff1744]" : "border-zinc-200"}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: img_2.url,
                                    alt: "Image actuelle",
                                    className: "h-full w-full object-cover"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
                                    lineNumber: 82,
                                    columnNumber: 245
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: {
                                        "ExistingProductImagesEditor[items.map() > <button>.onClick]": (e_0)=>handleRemove(img_2.id, e_0)
                                    }["ExistingProductImagesEditor[items.map() > <button>.onClick]"],
                                    className: "absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-600/80 text-[9px] text-white hover:bg-red-700",
                                    children: "×"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
                                    lineNumber: 82,
                                    columnNumber: 328
                                }, this),
                                img_2.id === primaryId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "absolute inset-x-0 bottom-0 bg-black/60 text-[9px] font-semibold text-white px-1 py-0.5 text-center",
                                    children: "Principale"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
                                    lineNumber: 84,
                                    columnNumber: 258
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
                            lineNumber: 80,
                            columnNumber: 109
                        }, this)
                    }, img_2.id, false, {
                        fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
                        lineNumber: 80,
                        columnNumber: 62
                    }, this)
            }["ExistingProductImagesEditor[items.map()]"])
        }, void 0, false);
        $[6] = handleRemove;
        $[7] = items;
        $[8] = primaryId;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    let t5;
    if ($[10] !== primaryId) {
        t5 = primaryId !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "hidden",
            name: "primaryExistingId",
            value: primaryId
        }, void 0, false, {
            fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
            lineNumber: 95,
            columnNumber: 32
        }, this);
        $[10] = primaryId;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    let t6;
    if ($[12] !== removedIds) {
        t6 = removedIds.map(_ExistingProductImagesEditorRemovedIdsMap);
        $[12] = removedIds;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    let t7;
    if ($[14] !== t4 || $[15] !== t5 || $[16] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t4,
                t5,
                t6
            ]
        }, void 0, true);
        $[14] = t4;
        $[15] = t5;
        $[16] = t6;
        $[17] = t7;
    } else {
        t7 = $[17];
    }
    return t7;
}
_s(ExistingProductImagesEditor, "A+YEE1xt0FpNdRc/CggYTvzmHfc=");
_c = ExistingProductImagesEditor;
function _ExistingProductImagesEditorRemovedIdsMap(id_1) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: "hidden",
        name: "removeImageIds",
        value: id_1
    }, id_1, false, {
        fileName: "[project]/src/components/admin/ExistingProductImagesEditor.tsx",
        lineNumber: 122,
        columnNumber: 10
    }, this);
}
function _ExistingProductImagesEditorImagesFind(img) {
    return img.isPrimary;
}
var _c;
__turbopack_context__.k.register(_c, "ExistingProductImagesEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_admin_e9d23005._.js.map