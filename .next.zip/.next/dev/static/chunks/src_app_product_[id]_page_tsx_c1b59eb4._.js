(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_product_[id]_page_tsx_977888d5._.js",
  "static/chunks/node_modules_next_b9dd3579._.js"
],
    source: "dynamic"
});
