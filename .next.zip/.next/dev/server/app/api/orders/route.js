var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/route.js")
R.c("server/chunks/node_modules_next_9e20cb28._.js")
R.c("server/chunks/[root-of-the-server]__8c6e2fb1._.js")
R.c("server/chunks/_next-internal_server_app_api_orders_route_actions_9a6edca0.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/orders/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/orders/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
