var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/products/route.js")
R.c("server/chunks/node_modules_next_1b4fe249._.js")
R.c("server/chunks/[root-of-the-server]__1dbc9e50._.js")
R.c("server/chunks/_next-internal_server_app_api_products_route_actions_9a81c53e.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/products/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/products/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
