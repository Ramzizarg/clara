module.exports = [
"[project]/.next-internal/server/app/api/product/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_product_route_actions_bcbd0b70.js.map