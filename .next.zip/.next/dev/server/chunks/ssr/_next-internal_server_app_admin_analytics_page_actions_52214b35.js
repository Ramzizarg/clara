module.exports = [
"[project]/.next-internal/server/app/admin/analytics/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_analytics_page_actions_52214b35.js.map