var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1780a17c._.js")
R.c("server/chunks/[root-of-the-server]__5e0842cd._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_route_actions_60052b14.js")
R.m(48527)
module.exports=R.m(48527).exports
